package com.example.travel;

public class FlightBooking {
	public void book(String destination) {
		System.out.println("Flight booked to: " + destination);
	}

	
}
