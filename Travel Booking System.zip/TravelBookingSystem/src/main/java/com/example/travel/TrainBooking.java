package com.example.travel;

public class TrainBooking {
	public void book(String destination) {
		System.out.println("Train booked to: " + destination);
	}

}
